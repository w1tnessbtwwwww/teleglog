# Teleglog Library

Someday here will be the source code of the library to provide logging of your application in the telegram bot
